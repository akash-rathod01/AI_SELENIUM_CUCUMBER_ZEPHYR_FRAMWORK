"""Generate an AuditBoard-style quality dashboard for the auto completion project."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# `parents[3]` climbs from reporting -> project -> projects -> repo root.
ROOT = Path(__file__).resolve().parents[3]
PROJECT_KEY = "auto_completion_projcet"
PROJECT_REPORT_DIR = ROOT / "reports" / PROJECT_KEY
RUN_HISTORY_PATH = ROOT / "reports" / "run_history.json"
BEHAVE_REPORT_PATH = PROJECT_REPORT_DIR / "behave-report.json"
OUTPUT_PATH = PROJECT_REPORT_DIR / "quality_dashboard.html"


@dataclass
class ScenarioResult:
    feature: str
    name: str
    status: str
    duration: float
    failed_step: Optional[str] = None
    error: Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "feature": self.feature,
            "name": self.name,
            "status": self.status,
            "duration": round(self.duration, 2),
            "failed_step": self.failed_step,
            "error": self.error,
        }


def load_run_history(limit: int = 10) -> List[Dict[str, Any]]:
    if not RUN_HISTORY_PATH.exists():
        return []
    data = json.loads(RUN_HISTORY_PATH.read_text(encoding="utf-8"))
    records = [item for item in data if item.get("project") == PROJECT_KEY]
    records.sort(key=lambda item: item.get("timestamp", ""), reverse=True)
    return records[:limit]


def load_behave_report() -> List[ScenarioResult]:
    if not BEHAVE_REPORT_PATH.exists():
        return []
    raw = json.loads(BEHAVE_REPORT_PATH.read_text(encoding="utf-8"))
    features = raw if isinstance(raw, list) else [raw]
    scenarios: List[ScenarioResult] = []
    for feature in features:
        feature_name = feature.get("name", "Unnamed Feature")
        for element in feature.get("elements", []):
            if element.get("type") != "scenario":
                continue
            status = element.get("status", "unknown")
            duration = 0.0
            failed_step_name: Optional[str] = None
            error_text: Optional[str] = None
            for step in element.get("steps", []):
                result = step.get("result", {})
                duration += float(result.get("duration", 0.0) or 0.0)
                if result.get("status") == "failed" and not failed_step_name:
                    failed_step_name = step.get("name")
                    message = result.get("error_message")
                    if isinstance(message, list):
                        error_text = "\n".join(message[:6])
                    elif isinstance(message, str):
                        error_text = message
            scenarios.append(
                ScenarioResult(
                    feature=feature_name,
                    name=element.get("name", "Unnamed Scenario"),
                    status=status,
                    duration=duration,
                    failed_step=failed_step_name,
                    error=error_text,
                )
            )
    return scenarios


def build_payload() -> Dict[str, Any]:
    scenarios = load_behave_report()
    history = load_run_history()

    status_counts: Dict[str, int] = {"passed": 0, "failed": 0, "skipped": 0}
    feature_map: Dict[str, Dict[str, int]] = {}
    slowest = sorted(scenarios, key=lambda s: s.duration, reverse=True)[:6]
    for scenario in scenarios:
        status_counts[scenario.status] = status_counts.get(scenario.status, 0) + 1
        feature_entry = feature_map.setdefault(
            scenario.feature,
            {"passed": 0, "failed": 0, "skipped": 0},
        )
        feature_entry[scenario.status] = feature_entry.get(scenario.status, 0) + 1

    failed_scenarios = [s for s in scenarios if s.status == "failed"]
    failed_scenarios.sort(key=lambda s: s.duration, reverse=True)
    timeline = [
        {
            "run_id": item.get("run_id"),
            "timestamp": item.get("timestamp"),
            "passed": item.get("passed", 0),
            "failed": item.get("failed", 0),
            "skipped": item.get("skipped", 0),
        }
        for item in history
    ]

    return {
        "generated_at": datetime.utcnow().isoformat(),
        "project": PROJECT_KEY,
        "summary": {
            "total_scenarios": len(scenarios),
            "passed": status_counts.get("passed", 0),
            "failed": status_counts.get("failed", 0),
            "skipped": status_counts.get("skipped", 0),
            "latest_run": timeline[0] if timeline else None,
        },
        "failed_scenarios": [item.as_dict() for item in failed_scenarios[:10]],
        "feature_breakdown": {
            "labels": list(feature_map.keys()),
            "passed": [feature_map[name].get("passed", 0) for name in feature_map],
            "failed": [feature_map[name].get("failed", 0) for name in feature_map],
            "skipped": [feature_map[name].get("skipped", 0) for name in feature_map],
        },
        "status_counts": status_counts,
        "run_timeline": timeline,
        "slowest": [item.as_dict() for item in slowest],
    }


def render_dashboard() -> None:
    payload = build_payload()
    PROJECT_REPORT_DIR.mkdir(parents=True, exist_ok=True)
    html = DASHBOARD_TEMPLATE.replace("__DASHBOARD_DATA__", json.dumps(payload, indent=2))
    OUTPUT_PATH.write_text(html, encoding="utf-8")
    print(f"Dashboard written to {OUTPUT_PATH}")


DASHBOARD_TEMPLATE = """<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <title>Auto Completion Quality Dashboard</title>
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\" />
  <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin />
  <link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap\" rel=\"stylesheet\" />
  <script src=\"https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js\" defer></script>
  <style>
    :root {
      color-scheme: light;
      --bg: #f5f6fb;
      --panel: #ffffff;
      --text: #1f2937;
      --muted: #6b7280;
      --border: #e5e7eb;
      --accent: #2563eb;
      --accent-soft: rgba(37, 99, 235, 0.12);
      font-family: 'Inter', system-ui, sans-serif;
    }
    body {
      margin: 0;
      background: var(--bg);
      padding: 32px;
      color: var(--text);
    }
    h1 {
      margin-bottom: 4px;
      font-size: clamp(1.8rem, 2.5vw, 2.4rem);
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 24px;
    }
    .panel {
      background: var(--panel);
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 12px 24px rgba(15, 23, 42, 0.06);
      border: 1px solid var(--border);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9rem;
    }
    th, td {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border);
      text-align: left;
    }
    th {
      font-weight: 600;
      color: var(--muted);
      text-transform: uppercase;
      font-size: 0.7rem;
      letter-spacing: 0.08em;
    }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    .status-pill.passed { background: rgba(34,197,94,0.15); color: #047857; }
    .status-pill.failed { background: rgba(239,68,68,0.15); color: #dc2626; }
    .status-pill.skipped { background: rgba(234,179,8,0.2); color: #b45309; }
    .side-metrics {
      display: grid;
      gap: 12px;
      margin-top: 16px;
    }
    .metric-card {
      padding: 16px;
      background: var(--panel);
      border-radius: 12px;
      border: 1px solid var(--border);
    }
    .metric-card h3 {
      margin: 0 0 4px;
      font-size: 0.85rem;
      color: var(--muted);
    }
    .metric-card .value {
      font-size: 1.8rem;
      font-weight: 700;
    }
    .small-text {
      font-size: 0.8rem;
      color: var(--muted);
    }
    .chart-wrap {
      height: 240px;
      position: relative;
    }
    .two-col {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
    }
    .scroll-area {
      max-height: 240px;
      overflow-y: auto;
    }
  </style>
</head>
<body>
  <header style=\"margin-bottom:24px;\">
    <h1>Auto Completion QA Dashboard</h1>
    <p class=\"small-text\">Realtime quality view for https://dotesthere.com/. Updated <span id=\"generatedAt\"></span>.</p>
  </header>
  <div class=\"grid\">
    <section class=\"panel\" style=\"grid-column: span 2;\">
      <h2 style=\"margin-bottom:12px;\">Critical Scenario Watchlist</h2>
      <div class=\"scroll-area\">
        <table id=\"failedTable\"></table>
      </div>
    </section>
    <aside style=\"display:flex; flex-direction:column; gap:16px;\">
      <div class=\"panel\">
        <h2 style=\"margin-bottom:12px;\">Execution Snapshot</h2>
        <div class=\"side-metrics\">
          <div class=\"metric-card\">
            <h3>Total Scenarios</h3>
            <div class=\"value\" id=\"metricTotal\">0</div>
          </div>
          <div class=\"metric-card\">
            <h3>Passed</h3>
            <div class=\"value\" id=\"metricPassed\">0</div>
          </div>
          <div class=\"metric-card\">
            <h3>Failed</h3>
            <div class=\"value\" id=\"metricFailed\">0</div>
          </div>
          <div class=\"metric-card\">
            <h3>Skipped</h3>
            <div class=\"value\" id=\"metricSkipped\">0</div>
          </div>
        </div>
      </div>
      <div class=\"panel\">
        <h2 style=\"margin-bottom:12px;\">Latest Run</h2>
        <p class=\"small-text\" id=\"latestRun\">No historical data</p>
      </div>
    </aside>
  </div>

  <div class=\"grid\" style=\"margin-top:24px;\">
    <section class=\"panel\">
      <h2 style=\"margin-bottom:12px;\">Status Distribution</h2>
      <div class=\"chart-wrap\"><canvas id=\"statusChart\"></canvas></div>
    </section>
    <section class=\"panel\">
      <h2 style=\"margin-bottom:12px;\">Feature Health</h2>
      <div class=\"chart-wrap\"><canvas id=\"featureChart\"></canvas></div>
    </section>
    <section class=\"panel\">
      <h2 style=\"margin-bottom:12px;\">Slowest Executions</h2>
      <table id=\"slowTable\"></table>
    </section>
  </div>

  <div class=\"panel\" style=\"margin-top:24px;\">
    <h2 style=\"margin-bottom:12px;\">Run History</h2>
    <div class=\"chart-wrap\"><canvas id=\"historyChart\"></canvas></div>
  </div>

<script>
  const data = __DASHBOARD_DATA__;

  const setStatusPill = (status) => {
    const base = document.createElement('span');
    base.className = `status-pill ${status}`;
    base.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    return base.outerHTML;
  };

  document.getElementById('generatedAt').textContent = new Date(data.generated_at).toLocaleString();
  document.getElementById('metricTotal').textContent = data.summary.total_scenarios;
  document.getElementById('metricPassed').textContent = data.summary.passed;
  document.getElementById('metricFailed').textContent = data.summary.failed;
  document.getElementById('metricSkipped').textContent = data.summary.skipped;

  if (data.summary.latest_run) {
    const run = data.summary.latest_run;
    const ts = new Date(run.timestamp).toLocaleString();
    document.getElementById('latestRun').innerHTML = `Run ${run.run_id} on ${ts}<br>Passed: ${run.passed} · Failed: ${run.failed} · Skipped: ${run.skipped}`;
  }

  const failedTable = document.getElementById('failedTable');
  if (data.failed_scenarios.length) {
    const header = `<tr><th>Scenario</th><th>Feature</th><th>Status</th><th>Duration (s)</th></tr>`;
    const rows = data.failed_scenarios.map(item => {
      return `<tr><td>${item.name}</td><td>${item.feature}</td><td>${setStatusPill('failed')}</td><td>${item.duration}</td></tr>`;
    }).join('');
    failedTable.innerHTML = header + rows;
  } else {
    failedTable.innerHTML = '<tr><td>No failed scenarios</td></tr>';
  }

  const slowTable = document.getElementById('slowTable');
  if (data.slowest.length) {
    const header = `<tr><th>Scenario</th><th>Feature</th><th>Duration (s)</th><th>Status</th></tr>`;
    const rows = data.slowest.map(item => {
      return `<tr><td>${item.name}</td><td>${item.feature}</td><td>${item.duration}</td><td>${setStatusPill(item.status)}</td></tr>`;
    }).join('');
    slowTable.innerHTML = header + rows;
  } else {
    slowTable.innerHTML = '<tr><td>No recent runs</td></tr>';
  }

  const statusCtx = document.getElementById('statusChart');
  const statusData = {
    labels: ['Passed', 'Failed', 'Skipped'],
    datasets: [{
      label: 'Scenarios',
      data: [data.status_counts.passed || 0, data.status_counts.failed || 0, data.status_counts.skipped || 0],
      backgroundColor: ['#10b981', '#ef4444', '#facc15']
    }]
  };
  new Chart(statusCtx, { type: 'doughnut', data: statusData, options: { plugins: { legend: { position: 'bottom' } } } });

  const featureCtx = document.getElementById('featureChart');
  new Chart(featureCtx, {
    type: 'bar',
    data: {
      labels: data.feature_breakdown.labels,
      datasets: [
        { label: 'Passed', data: data.feature_breakdown.passed, backgroundColor: '#10b981' },
        { label: 'Failed', data: data.feature_breakdown.failed, backgroundColor: '#ef4444' },
        { label: 'Skipped', data: data.feature_breakdown.skipped, backgroundColor: '#f59e0b' }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { stacked: true },
        y: { stacked: true, beginAtZero: true }
      }
    }
  });

  const historyCtx = document.getElementById('historyChart');
  const historyLabels = data.run_timeline.map(item => item.run_id).reverse();
  const passData = data.run_timeline.map(item => item.passed).reverse();
  const failData = data.run_timeline.map(item => item.failed).reverse();
  new Chart(historyCtx, {
    type: 'line',
    data: {
      labels: historyLabels,
      datasets: [
        { label: 'Passed', data: passData, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.15)', tension: 0.3, fill: true },
        { label: 'Failed', data: failData, borderColor: '#ef4444', backgroundColor: 'rgba(239,68,68,0.15)', tension: 0.3, fill: true }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom' } }
    }
  });
</script>
</body>
</html>
"""


if __name__ == "__main__":
    render_dashboard()
